#==================================================
# �𵨸� �ڵ�����
#==================================================


# 1. ������ ���� : train : test = 8 : 2

index <-        (   ,   )
     <-     [     ,     ]
     <-     [     ,     ]
     
# 2. �н�  
     <-     (     ~    , data =     )

# 3. ����
     <-     (     , newdata =    )

     
# 4. ��
if(!require(Metrics)) {
  install.packages("Metrics")
  library(Metrics)
}

mse(        ,        )
rmse(        ,        )
mae(        ,        )
mape(        ,        )





