#==================================================
# �𵨸� �ѷ�����
#==================================================

# 0. ȯ���غ�

library(caret)
if(!require(class)) { install.packages("class") ; library(class) }
if(!require(Metrics)) { install.packages("Metrics") ; library(Metrics) }

# 1. Titanic ------------
#   1.1 �����ͼ� �и� ------------------------

set.seed(2019)
indexes <- sample(1:nrow(titanic.0)
                  , size=0.3*nrow(titanic.0))

# Split data
test <- titanic.0[indexes,]
train <- titanic.0[-indexes,]

#   1.2 �𵨸� ---------------------------------------------------

#�𵨻���
model.1 <- glm(Survived ~ Sex + Pclass + Age + SibSp  + Embarked
               , family = binomial
               , data = train)

#   1.3 ����(�𵨰���) --------------------------------------------


fit.results.1 <- predict(model.1, newdata=test, type='response')
fit.results.New <- ifelse(fit.results.1 >= 0.5,1,0)

#   1.4 �� -------------------

fit.results.New <- as.factor(fit.results.New)

cm <- confusionMatrix(fit.results.New, test$Survived)

c(cm$overall[1], cm$byClass[1], cm$byClass[2])



# 2. airquality ------------
#   2.1 �����ͼ� �и� ------------------------

set.seed(2019)
indexes <- sample(1:nrow(air2)
                  , size=0.3*nrow(air2))

# Split data
test <- air2[indexes,]
train <- air2[-indexes,]

#   2.2 �𵨸� ---------------------------------------------------

#�𵨻���
model.1 <- knnreg(Ozone ~ ., k = 3, data = train)

#   2.3 ����(�𵨰���) --------------------------------------------

fit.results.1 <- predict(model.1, newdata=test)

#   2.4 �� -------------------

rmse(test$Ozone,fit.results.1)
mape(test$Ozone,fit.results.1)

